from django.urls import path
from django.contrib.auth.views import LogoutView, LoginView
from .views import CustomLogoutView  # Ensure CustomLogoutView is imported correctly
from . import views

urlpatterns = [
    path('', views.HomePageView.as_view(), name="home"),
    path('detail/<int:pk>/', views.ContactDetailView.as_view(), name="detail"),
    path('search/', views.search, name="search"),
    path('contacts/create/', views.ContactCreateView.as_view(), name="create"),  # Added trailing slash
    path('contacts/update/<int:pk>/', views.ContactUpdateView.as_view(), name="update"),  # Added trailing slash
    path('contacts/delete/<int:pk>/', views.ContactDeleteView.as_view(), name="delete"),  # Added trailing slash
    path('signup/', views.SignUpView.as_view(), name="signup"),
    path('login/', LoginView.as_view(), name='login'),
    path('logout/', CustomLogoutView.as_view(), name='logout'),  # Ensure CustomLogoutView is used
]